'''

COMP30024 Project Player module 
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''

from game2 import Game
import random

WHITE = 'O'
BLACK = '@'
INF = float('inf')

class Player(object):

    '''
    Defines a module that plays Watch Your Back! in accordance
    with the Part B project specification. 
    
    Plays a random move from list of legal moves. 
    
    Attributes:
        colour ('char'): token of the player
        opponent ('char'): token of the opponent 
        game ('Game'): current state of the game 
    
    Functions: 
        action(self,turns): returns next move for the player 
        update(self,action): updates game according to opponent's action
    '''
    def __init__(self, colour):
        
        if colour == 'black':
            self.opponent = WHITE
            self.colour = BLACK
        elif colour == 'white':
            self.opponent = BLACK
            self.colour = WHITE
        
        self.game = Game()
        
    
    def action(self, turns):
        
        self.game.player = self.colour
        
        move_list = self.game.moves()
        
        if move_list == []:
            self.game.make_move(None)
            return None
        
        move = random.choice(move_list)
            
        self.game.make_move(move)
        
        return move
    
    def update(self, action):
        self.game.make_move(action)
        

            
            