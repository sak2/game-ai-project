'''

COMP30024 Project Game module 
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''

class Player(object):

    '''
    Empty player class.
    
    Attributes:
        colour ('char'): token of the player
        opponent ('char'): token of the opponent 
        game ('Game'): current state of the game 
    
    Functions: 
        action(self,turns): returns next move for the player 
        update(self,action): updates game according to opponent's action
    '''
    def __init__(self, colour):
        return
    
    def action(self, turns):
        return None
    
    def update(self, action):
        return
        

            
            