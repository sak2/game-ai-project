'''

COMP30024 Project Player module 
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''

from game2 import Game
import csv
import random
from math import exp, tanh
from node import Node
from copy import deepcopy

FIRST_SHRINK = 152
SECOND_SHRINK = 216
B = 0.027
E = 0.1
DEPTH = 8
WHITE = 'O'
BLACK = '@'

INF = float('inf')


class Player():
    '''
    Defines a module that plays Watch Your Back! in accordance
    with the Part B project specification. 
    
    Uses minimax with alpha-beta pruning. Eval function learnt via TDLeaf(Lambda)
    
    Attributes:
        colour ('char'): token of the player
        opponent ('char'): token of the opponent 
        game ('Game'): current state of the game 
    
    Functions: 
        action(self,turns): returns next move for the player 
        update(self,action): updates game according to opponent's action
    '''
    def __init__(self, colour, weights=None):
        
        if colour == 'black':
            self.opponent = WHITE
            self.colour = BLACK
            self.sign = -1
        elif colour == 'white':
            self.opponent = BLACK
            self.colour = WHITE
            self.sign = 1
        
        self.game = Game()
        
        # read evaluation function weights 
        if weights != None:
            with open(weights,'r') as file:
                reader = csv.reader(file)
                self.weights = list(reader)
        elif weights == None:
            with open('weights.csv') as file:
                contents = file.read()
                contents_list = contents.split(',')
                self.weights = [float(x) for x in contents_list]
        
        # learning rate 
        self.alpha = 0.0001
        # lambda 
        self.l = 0.8
    
    def action(self, turns):
        '''
        Returns move to be taken by agent according to minimax search 
        '''
        
        legal = self.game.moves()
        
        if legal == []:
            self.game.make_move()
            return None
        if len(legal) == 1:
            self.game.make_move(legal[0])
            return legal[0]
        
        x = random.uniform(0,1)
        if x <= 1 - E:
            move = self.pick()
        else:
            move = random.choice(legal)
        
        self.game.make_move(move)
        
        return move
    
    def pick(self):
        '''
        Returns move chosen via minimax search
        '''
       
        root = Node(self.game)
        
        move_node, _ , _ = minimax(root, self, DEPTH, None)
        
        return move_node.path[0]
    
    def update(self, action):
        # apply the opponents move to the game 
        self.game.make_move(action)
    
    def learn(self,game_states,winner):
        '''
        Applies updates to learned weights according to 
        list of game states and the final result. 
        
        Uses TDLeaf(Lambda). 
        '''
        
        # make sure weights are up to date 
        with open('weights.csv') as file:
            contents = file.read()
            contents_list = contents.split(',')
            self.weights = [float(x) for x in contents_list]
        
        total_moves = len(game_states)
        
        # determine reward 
        if winner == 'W':
            reward = 1
        if winner == 'B':
            reward = -1
        if winner not in 'WB':
            reward = 0

        # calculate temporal differences 
        td = self.temporal_difference(game_states, reward)
        
        
        # make a copy of the current weights 
        new_weights = deepcopy(self.weights)
        
        for i in range(total_moves-1):
            ith_node = Node(game_states[i])
            
            # retrieve leaf node for current root node 
            _, _ , node = minimax(ith_node, self, DEPTH, None)
            features = convert_to_feature(node.game)
            node_result = node.game.check_goal()
            
            # retrieve reward for leaf state 
            if node_result[0]:
                if node_result[1] == 'O':
                    J = 1
                if node_result[1] == '@':
                    J = -1
                if node_result[1] == 0:
                    J = 0
            if not node_result:
                J = value(self.weights, features)
            
            # apply TDLeaf(Lambda) updates 
            for j in range(11):
                new_weights[j] += (0.002*self.alpha*sum((1 - J**2) \
                                    *features[j]*sum(td[i]*self.l**(m-t) \
                                    for m in range(t,total_moves-1)) \
                                    for t in range(total_moves-1)))
        
        # save new weights 
        with open('weights.csv','w',newline="") as f:
            w = csv.writer(f)
            w.writerow(new_weights)       
         
        return
    def temporal_difference(self, game_states, reward):
        '''
        Calculate d_t (temporal difference at time t) for each state 
        in game
        '''
        tds = []
        
        for i in range(len(game_states) - 1):
            
            # retrieve leaf node for current root
            ith_node = Node(game_states[i])
            _, _, node = minimax(ith_node, self, DEPTH, None)
            node_result = node.game.check_goal()
            
            # calculate reward for current state 
            if node_result[0]:
                if node_result[1] == 'O':
                    ith_value = 1
                if node_result[1] == '@':
                    ith_value = -1
                if node_result[1] == 0:
                    ith_value = 0
            if not node_result:
                ith_value = value(self.weights, convert_to_feature(node.game))
            
            # if we're looking at penultimate state, append the difference
            # between reward and current state value and continue 
            if i == len(game_states) - 2:
                tds.append(reward - ith_value)
                continue
            
            ith_node.expand()
            # find the child of the ith root node that corresponds to the
            # (i + 1)th root node 
            for child in ith_node.children:
                if child.game.board == game_states[i+1].board:
                    i1th_node = child
                    break
                    
            # retrieve leaf node for (i + 1)th node.
            _, _ , node = minimax(i1th_node, self, DEPTH, None)
            node_result = node.game.check_goal()
            
            # calculate the reward for the leaf node 
            if node_result[0]:
                if node_result[1] == 'O':
                    i1th_value = 1
                if node_result[1] == '@':
                    i1th_value = -1
                if node_result[1] == 0:
                    i1th_value = 0
            if not node_result:
                i1th_value = value(self.weights, convert_to_feature(node.game))   
            
            # calculate temporal difference 
            tds.append(i1th_value - ith_value)
        # return all temporal differences 
        return tds

def value(weights, features):
    '''
    Returns the value for given features 
    '''
    total = sum(i[0]*i[1] for i in zip(weights, features))
    return tanh(0.002*total)

def minimax(root,player, depth=4,cutoff_test=None):
    '''
    Based on alpha beta cutoff search from
    https://github.com/aimacode/aima-python/blob/master/games.py
    
    Returns the best child node of the root. 
    
    Parameters:
        root ('Node'): the root of the search tree
        depth ('int'): the depth cut off for the search
        cutoff_test ('func'): determines when a terminal node or the depth cutoff 
                                is reached
        eval_fun ('func'): scoring function for nodes 
        
    '''    
    def max_value(root, player, alpha, beta, depth):
        if cutoff_test(depth):
            features = convert_to_feature(root.game)
            result = root.game.check_goal()
            if result[0] and player.colour == result[1]:
                return player.sign*1, root
            elif result[0] and result[1] == 0:
                return player.sign*0, root
            elif result[0]:
                return player.sign*-1, root
            else:
                return player.sign*value(player.weights,features), root
        
        v = -INF
        
        if not root.expanded:
            root.expand()
        node = None
        for child in root.children:
            new_v, new_node = min_value(child,player,alpha,beta,depth+1)
            if new_v > v:
                node = new_node
                v = new_v
            v = max(v, new_v)
            if v >= beta:
                return v, node
            alpha = max(alpha,v)
        return v, node
    
    
    def min_value(root, player, alpha, beta, depth):
        if cutoff_test(depth):
            features = convert_to_feature(root.game)
            result = root.game.check_goal()
            if result[0] and result[1] == WHITE:
                return player.sign*1, root
            elif result[0] and result[1] == 0:
                return player.sign*0, root
            elif result[0]:
                return player.sign*-1, root
            else:
                return player.sign*value(player.weights,features), root
        v = INF
        node = None
        if not root.expanded:
            root.expand()
        for child in root.children:
            new_v, new_node = max_value(child,player, alpha,beta,depth+1)
            if new_v < v:
                node = new_node
                v = new_v
            if v <= alpha:
                return v, node
            beta = min(beta,v)
        return v, node
    
    cutoff_test = (lambda d: depth > d or root.game.check_goal()[0])
    
    best_score = -INF
    beta = INF
    best_action = None
    best_node = None
    
    if not root.expanded:
        root.expand()
    
    for child in root.children:
        v, node = min_value(child, player, best_score, beta, 1)
        if v > best_score:
            best_score = v
            best_action = child 
            best_node = node
    return best_action, v, best_node

def convert_to_feature(game):
    '''
    Converts game state to a feature vector of integers
    '''
    
    # number of white pieces
    num_white = 0
    # number of black pieces 
    num_black = 0
    
    # number of white pieces with no surrounding hostile objects
    num_white_free = 0
    
    # number of black pieces with no surrounding hostile objects 
    num_black_free = 0
    
    # number of white pieces with one surrounding hostile object 
    num_white_once = 0
    
    # number of black pieces with one surrounding hostile object 
    num_black_once = 0
    
    # number of white pieces with two surrounding hostile objects 
    num_white_twice = 0
    
    # number of black pieces with two surrounding hostile objects 
    num_black_twice = 0
    
    # number of turns passed in the game 
    turns_taken = game.turns

    # times the game board has shrunk 
    if game.turns < FIRST_SHRINK:
        num_shrunk = 0
    elif FIRST_SHRINK <= game.turns < SECOND_SHRINK:
        num_shrunk = 1
    elif game.turns >= SECOND_SHRINK:
        num_shrunk = 2
    
    
    next_player = game.player
    # which player plays next 
    if next_player == WHITE:
        next_turn = 1
    elif next_player == BLACK:
        next_turn = -1
    
    
    for i in range(8):
        for j in range(8):
            if game.board[(i,j)] == WHITE:
                surrounded = 0
                num_white += 1
                if ((i+1,j) in game.board.keys() and
                    (game.board[(i+1,j)] == BLACK or game.board[(i+1,j)] == 'X')):
                    surrounded += 1
                if ((i-1,j) in game.board.keys() and
                    (game.board[(i-1,j)] == BLACK or game.board[(i-1,j)] == 'X')):
                    surrounded += 1
                if ((i,j+1) in game.board.keys() and
                    (game.board[(i,j+1)] == BLACK or game.board[(i,j+1)] == 'X')):
                    surrounded += 1
                if ((i,j-1) in game.board.keys() and
                    (game.board[(i,j-1)] == BLACK or game.board[(i,j-1)] == 'X')):
                    surrounded += 1  
                
                if surrounded == 2:
                    num_white_twice += 1
                    num_white_once += 1
                if surrounded == 1:
                    num_white_once += 1
                if surrounded == 0:
                    num_white_free += 1
                
            if game.board[(i,j)] == BLACK:
                surrounded = 0
                num_black += 1
                if ((i+1,j) in game.board.keys() and
                    (game.board[(i+1,j)] == WHITE or game.board[(i+1,j)] == 'X')):
                    surrounded += 1
                if ((i-1,j) in game.board.keys() and
                    (game.board[(i-1,j)] == WHITE or game.board[(i-1,j)] == 'X')):
                    surrounded += 1
                if ((i,j+1) in game.board.keys() and
                    (game.board[(i,j+1)] == WHITE or game.board[(i,j+1)] == 'X')):
                    surrounded += 1
                if ((i,j-1) in game.board.keys() and
                    (game.board[(i,j-1)] == WHITE or game.board[(i,j-1)] == 'X')):
                    surrounded += 1 
                
                if surrounded == 2:
                    num_black_twice += 1
                    num_black_once += 1
                if surrounded == 1:
                    num_black_once += 1
                if surrounded == 0:
                    num_black_free += 1 
    
    return [turns_taken, next_turn, num_shrunk, num_white, num_black,
            num_white_once, num_black_once, num_white_twice, num_black_twice,
            num_white_free, num_black_free]
    