'''

COMP30024 Monte Carlo Tree Search 
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''

from game2 import Game
from node import Node
import random
import datetime
from copy import deepcopy
from math import log, sqrt
import numpy as np

# piece tokens
WHITE = 'O'
BLACK = '@'

# infinity float
INF = float('inf')


class MonteCarlo(object):
    '''
    Based on 
    https://jeffbradberry.com/posts/2015/09/intro-to-monte-carlo-tree-search/
    '''
    def __init__(self, game, **kwargs):
        
        self.game = game
        self.states = [game]
        
        # keep track of wins and plays in tree 
        self.wins = {}
        self.plays = {}
        self.wins_amaf = {}
        self.plays_amaf = {}
        
        # sets maximum playout time for each get_play call 
        seconds = kwargs.get('time', 0.3)
        self.calculation_time = datetime.timedelta(seconds=seconds)
        
        # sets maximum moves to be made in simulation
        self.max_moves = kwargs.get('max_moves', 250)
        
        self.a = 0.2
        # sets constant for UTC search 
        self.C = kwargs.get('C', 1.4)
        
    def update(self, state):
        self.states.append(state)
        
    def get_play(self):
        '''
        Returns best move from current state based on previous 
        playouts and simulations. 
        '''
        
        self.max_depth = 0
        state = self.states[-1]
        
        # set player to make next move 
        player = self.game.player
        
        # generate all legal moves 
        legal = self.game.moves()
        
        # if there is no choice to make, back out now 
        if not legal:
            return None
        if len(legal) == 1:
            return legal[0]
        
        games = 0
        
        # shuffle the moves
        np.random.shuffle(legal)
        
        # save the time simulations started 
        begin = datetime.datetime.utcnow()
        
        # while computational budget remains, run simulations 
        while datetime.datetime.utcnow() - begin < self.calculation_time:
            self.run_simulation()
            games += 1
        
        
        move_states = []
        
        # keep list of each legal move with the new state it creates 
        for move in legal:
            new_state = deepcopy(state)
            new_state.make_move(move)
            move_states.append((move,convert_to_list(new_state.board)))
        
        #print("Games: " + str(games))
        #print("Time elapsed: " + str(datetime.datetime.utcnow() - begin))
        
        
        # choose the move with the greatest percentage of wins from playouts 
        percent_wins, move = max((self.wins.get((player, S), 0)/self.plays.get((player, S), 1),p)
            for p, S in move_states)
        '''
        for x in sorted(
            ((100 * self.wins.get((player, S), 0) /
              self.plays.get((player, S), 1),
              self.wins.get((player, S), 0),
              self.plays.get((player, S), 0), p)
             for p, S in move_states),
            reverse=True
        ):
            print("{3}: {0:.2f}% ({1} / {2})".format(*x)) 
        
        print("Maximum search depth reached: " + str(self.max_depth))
        '''
        return move 
    def run_simulation(self):
        plays, wins = self.plays, self.wins
        plays_amaf, wins_amaf = self.plays_amaf, self.wins_amaf
        
        visited_states = set()
        state = deepcopy(self.game)
        player = state.player
        
        expand = True
        
        possible_moves = []
        
        for t in range(1,self.max_moves+1):
            
            # generate list of all legal moves 
            legal = state.moves()
            
            if legal == []:
                # if no moves to make, just forfeit 
                move = None
                state.make_move(move)
            elif len(legal) == 1:
                # if only one move to make, just make it 
                move = legal[0]
                state.make_move(move)
            else:
                # shuffle all legal moves 
                np.random.shuffle(legal)
                move_states = []
                
                # keep list of all moves and their respective states 
                for move in legal: 
                    new_state = deepcopy(state)
                    new_state.make_move(move)
                    new_board = convert_to_list(new_state.board)
                    move_states.append((move,new_board))
                
                
                # check if all move states have been played before 
                all_info = all(plays.get((player,S)) for p,S in move_states)
                
                # if all moves states have been played before, choose the node
                # with the maximum UTC value 
                # otherwise pick random move 
                if all_info:
                    R_amaf = {}
                    n_amaf = {}
                    for p,S in move_states:
                        R_amaf[(player,S)] = self.a*wins_amaf[(player,S)] + (1-self.a)*wins[(player,S)]
                        n_amaf[(player,S)] = self.a*plays_amaf[(player,S)] + (1-self.a)*plays[(player,S)] 
                    log_total = log(sum(n_amaf[(player,S)] for p,S in move_states))
                    _, move, board = max(((R_amaf[(player, S)] / n_amaf[(player, S)]) \
                                            + self.C * sqrt(log_total / n_amaf[(player, S)]), p, S) \
                                            for p, S in move_states)
                    possible = [(player, S) for p,S in move_states]
                    possible.remove((player, board))
                    possible_moves += possible
                    state.make_move(move)
                else:
                    move = random.choice(legal)
                    state.make_move(move)
            
            
            board = convert_to_list(state.board)
            
            
            # if move not in plays dictionary, add it if it is the first new node
            # encountered on this sim 
            if expand and (player,board) not in self.plays:
                expand = False
                self.plays[(player,board)] = 0
                self.plays_amaf[(player,board)] = 0
                self.wins[(player,board)] = 0
                self.wins_amaf[(player,board)] = 0
                if t > self.max_depth:
                    self.max_depth = t
                
            # add the state to list of visited states 
            visited_states.add((player,board))
            
            # change the player 
            player = state.player
            
            # check if the game has ended 
            goal = state.check_goal()
            
            if goal[0] and state.turns >=24:
                break
        
        
        # update simulation statistics for visited states 
        for player,state in visited_states:
            if (player,state) not in self.plays:
                continue
            if (player, state) in possible_moves:
                self.plays_amaf[(player, state)] += possible_moves.count((player, state))
            self.plays[(player,state)] += 1
            self.plays_amaf[(player, state)] += 1
            if player == goal[1]:
                self.wins[(player,state)] += 1
                self.wins_amaf[(player,state)] += 1
                if (player,state) in possible_moves:
                    self.wins_amaf[(player,state)] += 1
                
            
def convert_to_list(board):
    '''
    Converts a board dictionary into a list.
    This is to allow the board to be used as a 
    hashable key to a dictionary
    '''
    board_list = []
    for i in range(8):
        row = []
        for j in range(8):
            row.append(board[(j,i)])
        board_list.append(row)
    return tuple(tuple(x) for x in board_list)