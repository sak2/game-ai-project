'''

COMP30024 Project Part B
Self-play frameork
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''


import subprocess
from copy import deepcopy
from feature_conversion import convert_to_feature
from game2 import Game

def self_play(player1,player2):
    '''
    Runs a refereed game between player modules named by strings 'player1'
    and 'player2'
    
    Returns a list of game states and the winner of the game. 
    '''
    # run the program with the two players 
    stdoutdata = subprocess.check_output(['python','referee.py',player1,player2])
    
    # return the processed data as a tuple containing a 
    # list of dictionaries and the result
    return process_game(stdoutdata.decode("utf-8"))
    
def process_game(game):
    '''
    Returns the result of a game as a list of dictionaries
    and the result
    '''
    
    lines = game.splitlines()
    
    current_board_line = 0
    game_over = False
    
    states = []
    state = []
    winner = 'D'
    
    for i in range(4,len(lines)): 
        
        if "game over!" in lines[i]:
            game_over = True
            continue
        
        if game_over:
            winner = lines[i][8]
            break
        
        if current_board_line == 8:
            current_board_line = 0
            states.append(state)
            state = deepcopy(state)
            state = []
            continue
        
        state.append(lines[i].split())
        current_board_line += 1
    
    dict_states = []
    for state in states:
        state_dict = {(x,y):state[y][x] for x in range(8) for y in range(8)}
        dict_states.append(state_dict)
    return dict_states, winner


'''
X = []
Y = []        
net = Neural_Network('neural.csv')

results = {'white':0,'black':0,'draw':0}
for i in range(1,10001):
    print("Game " + str(i) + " started.")
    game_states, winner = self_play('neural_play','neural_play')
    print("Game " + str(i) + " ended.")
    if winner == 'W':
        reward = [1,0,0]
        results['white'] += 1
        print("White wins!")
    if winner == 'B':
        reward = [0,0,1]
        results['black'] += 1
        print("Black wins!")
    if winner not in 'WB':
        reward = [0,1,0]
        results['draw'] += 1
        print("Draw!")
    turns = 0
    player = 'O'
    for j in range(len(game_states)):
        game = Game(game_states[j],player,turns)
        X.append(convert_to_feature(game))
        Y.append(reward)
        turns += 1
        if player == 'O':
            player = '@'
        else:
            player = 'O'
    if i % 1000 == 0:
        net.train(X,Y,5000,True)
        X = []
        Y = []

game = Game()
features = convert_to_feature(game)
print('White won',results['white'],'games.')
print('Black won',results['black'],'games.')
print('There were',results['draw'],'drawn games.')
print(net.forward_prop(features)['a2'])
'''