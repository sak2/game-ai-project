'''

COMP30024 Project Player module 
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)

'''

from game2 import Game
from node import Node
import random

# piece tokens
WHITE = 'O'
BLACK = '@'

FIRST_SHRINK = 152
SECOND_SHRINK = 216

# chance of making a random move 
RANDOM_CHOICE = 0

# depth limit for minimax 
DEPTH_LIMIT = 12

# infinity float
INF = float('inf')

class Player(object):
    
    '''
    Defines a module that plays Watch Your Back! in accordance
    with the Part B project specification. 
    
    Attributes:
        colour ('char'): token of the player
        opponent ('char'): token of the opponent 
        game ('Game'): current state of the game 
    
    Functions: 
        action(self,turns): returns next move for the player 
        update(self,action): updates game according to opponent's action
    '''
    
    def __init__(self, colour):
        '''
        Parameters:
            colour ('char'): token being played by the player module
        '''
        
        if colour == 'black':
            self.opponent = WHITE
            self.colour = BLACK
            self.sign = -1
        elif colour == 'white':
            self.opponent = BLACK
            self.colour = WHITE
            self.sign = -1
        
        self.game = Game()
        
    
    def action(self, turns):
        
        # generate all legal moves for current game state        
        move_list = self.game.moves()
        
        # if there is no legal moves, forfeit turn
        if move_list == []:
            return None
        
        # generate a random number between 0 and 1 
        x = random.uniform(0,1)
        
        # if x is under our chance of a random choice make a random move 
        if x <= RANDOM_CHOICE:
            move = random.choice(move_list)
        elif x > RANDOM_CHOICE:
            # if move is to be non-random perform minimax search
            root = Node(self.game)
            best_node = minimax(root, self, DEPTH_LIMIT, None)
            move = best_node.path[0]
        
        # apply the chosen move to the game  
        self.game.make_move(move)
        
        # return the move taken 
        return move
    
    def update(self, action):
        # apply the opponents move to the game 
        self.game.make_move(action)
        
#@profile
def minimax(root,player, depth=4,cutoff_test=None):
    '''
    Based on alpha beta cutoff search from
    https://github.com/aimacode/aima-python/blob/master/games.py
    
    Returns the best child node of the root. 
    
    Parameters:
        root ('Node'): the root of the search tree
        depth ('int'): the depth cut off for the search
        cutoff_test ('func'): determines when a terminal node or the depth cutoff 
                                is reached
        eval_fun ('func'): scoring function for nodes 
        
    '''    
    def max_value(root, player, alpha, beta, depth):
        if cutoff_test(depth):
            white, black = root.game.count_pieces()
            return player.sign*(white - black)
        
        v = -INF
        
        if not root.expanded:
            root.expand()
        
        for child in root.children:
            v = max(v, min_value(child,player,alpha,beta,depth+1))
            if v >= beta:
                return v
            alpha = max(alpha,v)
        return v
    
    
    def min_value(root, player, alpha, beta, depth):
        if cutoff_test(depth):
            white, black = root.game.count_pieces()
            return player.sign*(white - black)
        v = INF
        if not root.expanded:
            root.expand()
        for child in root.children:
            v = min(v,max_value(child,player,alpha,beta,depth+1))
            if v <= alpha:
                return v
            beta = min(beta,v)
        return v
    
    cutoff_test = (lambda d: depth > d or root.game.check_goal()[0])
    
    best_score = -INF
    beta = INF
    best_action = None
    
    if not root.expanded:
        root.expand()
    
    for child in root.children:
        v = min_value(child, player, best_score, beta, 1)
        if v > best_score:
            best_score = v
            best_action = child 
    return best_action

