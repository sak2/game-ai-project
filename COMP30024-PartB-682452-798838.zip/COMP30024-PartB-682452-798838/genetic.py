'''

COMP30024 Genetic Framework
Semester 1 2018
Tamara Hogan (682452) & Saleh Ahmed Khan (798838)
Based on:
https://towardsdatascience.com/genetic-programming-for-ai-heuristic-optimization-9d7fdb115ee1

'''

import random
import csv
from selfplay import self_play
from copy import deepcopy

POPULATION = 20
CYCLES = 12
MUTATION_CHANCE = 0.15

def generate_population(count):
    ''' 
    Generate initial population with 'count' individuals
    '''
    
    population = []
    
    # include current best weights (from genetic.py or tdlearn.py)
    with open('weights.csv') as file:
        contents = file.read()
        contents_list = contents.split(',')
        population.append([float(x) for x in contents_list])
    
    # generate random weight vectors 
    for _ in range(count-1):
        population.append([random.uniform(-10,10) for _ in range(12)])
    
    # return the full population 
    return population

def check_fitness(specimen):
    '''
    Check the fitness of a given specimen by playing it against 
    a random agent 50 times.
    '''
    with open("weights.csv","w",newline="") as f:
        w = csv.writer(f)
        w.writerow(specimen)
    
    wins = 0
    
    for _ in range(50):
        _, winner = self_play('player2', 'tdlearn')
        if winner == 'B':
            wins += 1
    
    return wins

def breed(mother, father):
    '''
    Breed two specimens
    '''
    child = []
    if mother != father:
        # for each weight set the child's weight to be between mother and father 
        for i in range(12):
            if father[i] > mother[i]:
                child.append(random.uniform(mother[i]*0.95,father[i]*0.95))
            else:
                child.append(random.uniform(father[i]*0.95,mother[i]*0.95))
    
    return child

def mutate(specimen):
    '''
    Mutate a given specimen. 
    '''
    new_specimen = list(deepcopy(specimen))
    for i in range(12):
        x = random.uniform(0,1)
        # if a weight is to be mutated, add a random value 
        if x < MUTATION_CHANCE:
            new_specimen[i] += random.uniform(-0.5,0.5)
    return new_specimen

def evolve(pop):
    '''
    Evolve the population. Return new generation.
    '''
    
    scores = {}
    # check fitness for all specimens
    for i in range(len(pop)):
        # blah
        score = check_fitness(pop[i])
        if tuple(pop[i]) not in scores.keys():
            scores[tuple(pop[i])] = score
    
    # sort fitness scores best to worst 
    sorted_scores = sorted(scores,key=scores.get, reverse =True)
    
    # keep track of best weights from this generation 
    best_weights = sorted_scores[0]
    best_score = scores[best_weights]
    
    # keep top 20% + a random sample to ensure gene diversity 
    retain = sorted_scores[:5]
    retain = retain + random.sample(sorted_scores[5:],1)
    
    # shuffle the specimens 
    random.shuffle(retain)
    
    
    # breed number of children necessary to bring population back up 
    num_children = len(pop) - len(retain)
    children = []
    for i in range(num_children):
        par = random.sample(retain, 2)
        child = breed(par[0],par[1])
        children.append(child)
        
    new_pop = children + retain
    
    mutated_pop = []
    # mutate specimens
    for specimen in new_pop:
        mutated_pop.append(mutate(specimen))
    
    # return new generation, as well as best specimen from this generation 
    return mutated_pop, best_weights, best_score
    

# generate population
population = generate_population(20)
best = 0
best_weights = []

for i in range(CYCLES):
    print("This is generation " + str(i) + ".")
    population, best_specimen, best_score = evolve(population)
    print("The best specimen was: " + str(best_specimen))
    print("This specimen scored " + str(best_score))
    if best_score > best:
        best_weights = best_specimen
        best = best_score

# write best weights from evolution into file 
with open("weights.csv","w",newline="") as f:
        w = csv.writer(f)
        w.writerow(list(best_weights)) 

